#ifndef CGI_EXECUTOR_HPP
#define CGI_EXECUTOR_HPP

#include <iostream>

#endif