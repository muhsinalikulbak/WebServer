#include <iostream>
#include <cstdlib> // getenv için
#include <string>

int main() {
    // 1. KURAL: HTTP Başlığı ve iki yeni satır
    std::cout << "Content-Type: text/html\n\n";
    
    // HTML Gövdesi
    std::cout << "<!DOCTYPE html>\n<html>\n<head><title>C++ CGI Test</title></head>\n<body>\n";
    std::cout << "<h1>C++ ile Web'e Merhaba!</h1>\n";
    
    // Çevre değişkenini okuma
    char* query_string = std::getenv("QUERY_STRING");
    char* request_method = std::getenv("REQUEST_METHOD");
    
    if (request_method) {
        std::cout << "<p>Gelen Istek Tipi: <strong>" << request_method << "</strong></p>\n";
    }
    
    // Gelen bir parametre var mı kontrolü
    if (query_string && std::string(query_string).length() > 0) {
        std::cout << "<p>URL Parametreleri: <strong>" << query_string << "</strong></p>\n";
    } else {
        std::cout << "<p>Herhangi bir parametre bulunamadi. URL sonuna <code>?veri=cpp_test</code> eklemeyi deneyin.</p>\n";
    }
    
    std::cout << "</body>\n</html>\n";
    
    return 0;
}